num = int(input('Please add a number which is lower than 20: '))
while num>=20:
    print('Too high!')
    num = int(input('Please add a number which is lower than 20: '))
else:
    print ('Thank you! ^^')