color = input('Please enter your favourite color: ')
if color=='red' or color=='RED' or color=='Red':
    print('I like red too!')
else:
    print("I don't like",color,", I prefer red!")