num = int(input("Please add a number: "))
if num < 10:
    print("Too low!")
elif 20 >= num >= 10:
    print('Correct!')
else:
    print ("Too high!")