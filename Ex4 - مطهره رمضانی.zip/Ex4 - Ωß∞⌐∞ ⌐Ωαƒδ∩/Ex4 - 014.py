num = int(input('Please add a number between 10 & 20 (inclusive): '))
if 20>=num>=10:
    print('Thank you!')
else:
    print('Incorrect answer!')