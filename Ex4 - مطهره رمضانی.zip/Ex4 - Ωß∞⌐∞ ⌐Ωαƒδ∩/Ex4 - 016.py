ans = input('Is it raining?: ')
answer = ans.lower()
if answer == "yes":
    ans2 = input('Is it windy?: ')
    answer2 = ans2.lower()
    if answer2 == "yes":
        print("It's too windy for an umbrella!")
    else:
        print("take an umbrella.")
else:
    print("Enjoy your day!")