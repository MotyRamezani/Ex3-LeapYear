num = int(input('Please choose a number amoung 1, 2 or 3: '))
if num == 1:
    print("Thank you!")
elif num == 2:
    print("Well done!")
elif num == 3:
    print("Correct!")
else:
    print("Error Message!")