num1 = int(input('Please add a number: '))
num2 = int(input('Please add another number: '))
if num1>num2:
    print (num2,',',num1)
else:
    print(num1,',',num2)