num = 0
g_n1 = input("Please enter the name of the person whom you want to invite to the party: ")
g_n2 = g_n1.lower()
g_n = g_n2.title()
print(g_n,"has been invited to the party.")
num+=1
ans = input("Do you want to invite another guest to the party?(Yes or No) ")
ans1 = ans.lower()
while ans1 == 'yes':
    g_n3 = input("Please write the guest's name: ")
    g1 = g_n3.lower()
    guest_n = g1.title()
    print(guest_n,"has been invited to the party.")
    num+=1
    ans = input("Do you want to invite another guest to the party?(Yes or No) ")
    ans1 = ans.lower()
print("You've invited",num,"person to the party.")