num = int(input("Please add a number between 10 & 20 (inclusive): "))
while num>20 or num<10:
    if num<10:
        print("Too low, Try again!")
        num = int(input("Please add a number between 10 & 20: "))
    elif num>20:
        print("Too high, Try again!")
        num = int(input("Please add a number between 10 & 20: "))
print("Thank you!")