total = 0
while total <= 50:
    num = int(input("Please add a number: "))
    total+=num
    print("The total is=",total)