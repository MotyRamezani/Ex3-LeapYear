num = 10
print("There are",num,"green bottles hanging on the wall,"
      ,num,"green bottles hanging on the wall, and if 1 green bottles should accidentally fall.")
num-=1
num1 = int(input("How many green bottles will be hanging on the wall? "))
while num != 0:
    if num != num1:
        print("NO, Try again.")
        num1 = int(input("How many green bottles will be hanging on the wall? "))
    if num == num1:
        print("There will be",num,"green bottles hanging on the wall.")
        print("There are",num,"green bottles hanging on the wall,"
              ,num,"green bottles hanging on the wall, and if 1 green bottles should accidentally fall.")
        num-=1
        num1 = int(input("How many green bottles will be hanging on the wall? "))
print("There are no more green bottles hanging on the wall!")