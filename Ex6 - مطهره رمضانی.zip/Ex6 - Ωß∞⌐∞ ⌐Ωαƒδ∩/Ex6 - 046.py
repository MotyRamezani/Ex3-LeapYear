num = int(input("Please add a number: "))
while num<=5:
    num = int(input("Please add a number: "))
print("The last number you entered was a",num)