num1 = int(input("Please add a number: "))
num2 = int(input("Please add a number: "))
num = num1 + num2
ans1 = input("Do you want to add another number?(y or n) ")
ans = ans1.lower()
while ans == "y":
    num3 = int(input("Please add a number: "))
    num += num3
    ans1 = input("Do you want to add another number?(y or n) ")
    ans = ans1.lower()
print("The total is=",num)