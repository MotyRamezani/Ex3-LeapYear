count=0
compnum = 50
num = int(input("Please add a number: "))
count+=1
while compnum != num:
    if num<50:
        print("The added number is lower than the actual number!")
        num = int(input("Please add another number: "))
        count+=1
    elif num>50:
        print("The added number is higher than the actual number!")
        num = int(input("Please add another number: "))
        count+=1
print("Well Done!, you took",count,"attempts.")