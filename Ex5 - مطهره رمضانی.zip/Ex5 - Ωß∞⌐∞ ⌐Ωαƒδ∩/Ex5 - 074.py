Colors = ['Red','Blue','Yellow','Green','Violet','Purple','Pink','Black','Brown','Orange']
s_num = int(input("Please enter a number from 0 to 4 (4 is included): "))
while s_num<0 or s_num>4:
    s_num = int(input("Please enter a number from 0 to 4 (4 is included): "))
e_num = int(input("Please enter a number from 5 to 9 (9 is included): "))
while e_num<5 or e_num>9:
    e_num = int(input("Please enter a number from 5 to 9 (9 is included): "))
print(Colors[s_num:e_num+1]) #فرض بر این گرفته شد که رنگ مربوط به خود عدد ابتدا و انتها نیز نشان داده شود