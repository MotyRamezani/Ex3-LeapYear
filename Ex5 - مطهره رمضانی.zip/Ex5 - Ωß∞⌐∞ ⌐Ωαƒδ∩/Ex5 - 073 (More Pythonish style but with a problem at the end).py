food_dic = {}
l1=[1,2,3,4]
for i in l1:
    food = input ("Please add your favourite food: ")
    food1 = food.lower()
    food2 = food1.title()
    food_dic [i] = food2
    i+=1
print(food_dic)
f_l = list(food_dic.values())
f = input("Choose the food which you don't like anymore: ")
f1 = f.lower()
Food = f1.title()
f_l.remove(Food)
f_l.sort()

for i in range(1,len(f_l)+1):
    food_dic [i] = f_l[i-1]
    i+=1
    if i>3:
        break
#food_dic = { i : f_l[i] for i in range(0, len(f_l))}
print(food_dic)