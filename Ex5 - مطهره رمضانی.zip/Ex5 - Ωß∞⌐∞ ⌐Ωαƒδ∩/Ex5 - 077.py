guest_list = []
l1=[1,2,3]
for i in l1:
    g = input ("Please write the name of the person whom you want to invite to the party: ")
    g1 = g.lower()
    guest_name = g1.title()
    guest_list.append(guest_name)
    i+=1
ans = input("Do you want to invite another guest to the party?(Yes or No) ")
ans2 = ans.lower()
while ans2 == 'yes':
    g_n = input("Please write the guest's name: ")
    g1 = g_n.lower()
    guest_n = g1.title()
    guest_list.append(guest_n)
    ans = input("Do you want to invite another guest to the party?(Yes or No) ")
    ans2 = ans.lower()
if ans2 == 'no':
    print("Guest List= ",guest_list)
    
n = input ("Please choose one of the names from the list above: ")
n1 = n.lower()
name = n1.title()
chosen = guest_list.index(name)
print("Position on the list:",chosen)
answer = input("Do you still want this person to be invited to the party?(Yes or No) ")
answer2 = answer.lower()
if answer == 'no':
    guest_list.pop(chosen)
    print("Guest List= ",guest_list)