list1 = [123,456,789,369]
for i in list1:
    print (i)
num = int(input("Please enter a three-digit number : "))
if num in list1:
    print(list1.index(num))
else:
    print("That is not in the list!")