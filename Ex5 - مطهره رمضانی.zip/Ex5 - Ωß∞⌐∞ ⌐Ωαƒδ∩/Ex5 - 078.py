tv_p = ["The Office","Game of Trowns","Family Guy","Sponge Bob"]
for i in tv_p:
    print (i)
n = input ("Please name another TV program: ")
n1 = n.lower()
name = n1.title()
p = int(input ("Which position of the list do you like this TV program to be inserted in? "))
tv_p.insert(p,name)
print(tv_p)