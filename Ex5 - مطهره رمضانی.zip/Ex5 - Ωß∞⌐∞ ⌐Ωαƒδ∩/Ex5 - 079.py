nums = []
l1=[1,2,3]
for i in l1:
    n = int(input ("Please add a number: "))
    nums.append(n)
    print(nums)
    i+=1
ans = input ("Do you still want the last number which you've added to be saved?(Yes or No) ")
ans1 = ans.lower()
if ans == "no":
    nums.pop(-1)
    print(nums)