guest_list = []
l1=[1,2,3]
for i in l1:
    g = input ("Please write the name of the person whom you want to invite to the party: ")
    g1 = g.lower()
    guest_name = g1.title()
    guest_list.append(guest_name)
    i+=1
ans = input("Do you want to invite another guest to the party?(Yes or No) ")
ans2 = ans.lower()
while ans2 == "yes":
    g_n = input("Please write the guest's name: ")
    g1 = g_n.lower()
    guest_n = g1.title()
    guest_list.append(guest_n)
    ans = input("Do you want to invite another guest to the party?(Yes or No) ")
    ans2 = ans.lower()
if ans2 == "no":
    print('You have invited',len(guest_list),'persons to the patry.')