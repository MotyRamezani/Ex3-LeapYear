food_dic = {}
print("Please add 4 of your favourite food: ")
Food1_1 = input('Food1: ')
Food1_2 = Food1_1.lower()
Food1 = Food1_2.title()
Food2_1 = input('Food2: ')
Food2_2 = Food2_1.lower()
Food2 = Food2_2.title()
Food3_1 = input('Food3: ')
Food3_2 = Food3_1.lower()
Food3 = Food3_2.title()
Food4_1 = input('Food4: ')
Food4_2 = Food4_1.lower()
Food4 = Food4_2.title()
food_dic [1] = Food1
food_dic [2] = Food2
food_dic [3] = Food3
food_dic [4] = Food4
print(food_dic)
Food = int(input("Choose the number of the food which you don't like anymore: "))
food_dic.pop(Food)
print(food_dic) 