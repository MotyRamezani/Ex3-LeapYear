sport = ['Swimming','Volleyball']
add1 = input("What is your favourite sport? ")
add2 = add1.capitalize()
sport.append(add2)
sport.sort()
print (sport)