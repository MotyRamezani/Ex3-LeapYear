AtSchool = ['Math','Physics','Literature','History','Art','English']
print("School Objects:",AtSchool)
obj = input("Which object you don't like? ")
obj2 = obj.lower()
obj3 = obj2.title()
AtSchool.remove(obj3)
print(AtSchool)